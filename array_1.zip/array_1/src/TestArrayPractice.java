
/**
 * A simple tester class to test the ArrayPractice class methods
 * 
 * @author Morgan Dale
 *         version 1.0.0
 */

public class TestArrayPractice {

	public static void main(String args[]) {

		ArrayPractice ap = new ArrayPractice();

		ap.markAnalysisForEach();
	}

}
